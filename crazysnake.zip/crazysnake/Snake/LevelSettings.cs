﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Snake
{
    class LevelSettings
    {
        public void level(RadioButton a,RadioButton b,RadioButton c)
        {
            if(a.Checked == true)
            {
                Settings.Speed = 10;
            }
            else if (b.Checked == true)
            {
                Settings.Speed = 16;
            }
            else if (c.Checked == true)
            {
                Settings.Speed = 30;
            }
            Form2 f2 = new Form2();
            f2.Show();
        
        }
    }
}
