﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Snake
{
    class SnakeColor
    {
        public void snakecolor(RadioButton a,RadioButton b,RadioButton c,RadioButton d)
        {
            if (a.Checked == true)
            {
                Settings.snakeColour = Brushes.Pink;
            }
            else if (b.Checked == true)
            {
                Settings.snakeColour = Brushes.Purple;
            }
            else if (c.Checked == true)
            {

                Settings.snakeColour = Brushes.Green;
            }
            else if (d.Checked == true)
            {
                Settings.snakeColour = Brushes.Yellow;
            }
            Form1 f1 = new Form1();
            f1.Show();
        
        }
    }
}
