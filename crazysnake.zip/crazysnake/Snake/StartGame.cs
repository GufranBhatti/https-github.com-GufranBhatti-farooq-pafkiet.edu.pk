﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake
{
    class StartGame:Form1
    {
        Form1 f1 = new Form1();

        public void start()
        {
          
        }

    }
}
