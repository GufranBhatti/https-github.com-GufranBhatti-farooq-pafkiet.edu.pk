﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;

namespace Snake
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {


        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            SnakeColor snakecolor = new SnakeColor();
            snakecolor.snakecolor(radioButton1, radioButton2, radioButton3, radioButton4);
            this.Hide();

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }

    }

